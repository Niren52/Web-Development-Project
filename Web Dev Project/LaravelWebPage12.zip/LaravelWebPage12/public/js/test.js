$('document').ready(function() {
  console.log('page loaded');
});
